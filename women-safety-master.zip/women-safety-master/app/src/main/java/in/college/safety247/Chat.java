//package in.college.safety247;
//
//import android.app.Fragment;
//import android.app.ProgressDialog;
//import android.os.Bundle;
//import android.support.annotation.Nullable;
//import android.view.LayoutInflater;
//import android.view.Menu;
//import android.view.MenuInflater;
//import android.view.View;
//import android.view.ViewGroup;
//import android.widget.Button;
//import android.widget.EditText;
//
//import com.google.android.gms.maps.GoogleMap;
//import com.google.android.gms.maps.OnMapReadyCallback;
//import com.google.android.gms.maps.model.Marker;
//import com.google.android.gms.maps.model.Polyline;
//
//import java.util.ArrayList;
//import java.util.List;
//
//import Modules.DirectionFinderListener;
//import Modules.Route;
//
///**
// * Created by Charmy Garg on 18-Sep-16.
// */
//public class Chat extends android.support.v4.app.Fragment {
//
//    public Chat()
//    {}
//
//    @Override
//    public void onCreate(@Nullable Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);
//        setHasOptionsMenu(true);
//    }
//
//    @Nullable
//    @Override
//    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
//        return inflater.inflate(R.layout.activity_chat, container, false);
//    }
//
//    @Override
//    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
//        inflater.inflate(R.menu.chat_menu, menu);
//    }
//}
