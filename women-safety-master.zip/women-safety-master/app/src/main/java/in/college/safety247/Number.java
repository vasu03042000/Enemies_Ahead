package in.college.safety247;

/**
 * Created by Charmy Garg on 22-Oct-16.
 */
public class Number {

    private String number;


    public String getNumber() {
        return number;
    }

    public void setNumber(String number) {
        this.number = number;
    }
}
