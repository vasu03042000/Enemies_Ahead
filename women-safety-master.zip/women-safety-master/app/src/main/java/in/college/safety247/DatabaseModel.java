package in.college.safety247;

/**
 * Created by Charmy Garg on 09-Oct-16.
 */
public class DatabaseModel {

    private String name;
    private String number;


    public String getNumber() {
        return number;
    }

    public void setNumber(String number) {
        this.number = number;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
