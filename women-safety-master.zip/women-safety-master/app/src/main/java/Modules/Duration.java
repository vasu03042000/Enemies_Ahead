package Modules;

/**
 * Created by Charmy Garg on 02-Oct-16.
 */
public class Duration {
    public String text;
    public int value;

    public Duration(String text, int value) {
        this.text = text;
        this.value = value;
    }
}
